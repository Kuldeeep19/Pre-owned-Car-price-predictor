# Car-Price-Predictor
The project consists of a Car Price Predictor System developed using a linear regression model and UI developed in HTML, CSS Javascript, and Bootstrap. This project predicts the price of used cars based on multiple parameters like brand, model, fuel type, year of purchase, etc
